package android.support.v4.animation;
/* loaded from: classes.dex */
interface AnimatorProvider {
    ValueAnimatorCompat emptyValueAnimator();
}
