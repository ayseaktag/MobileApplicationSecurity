package android.support.v4.app;
/* loaded from: classes.dex */
class NotificationManagerCompatIceCreamSandwich {
    static final int SIDE_CHANNEL_BIND_FLAGS = 33;

    NotificationManagerCompatIceCreamSandwich() {
    }
}
