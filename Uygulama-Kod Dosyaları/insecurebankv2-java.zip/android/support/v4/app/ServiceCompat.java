package android.support.v4.app;
/* loaded from: classes.dex */
public class ServiceCompat {
    public static final int START_STICKY = 1;

    private ServiceCompat() {
    }
}
