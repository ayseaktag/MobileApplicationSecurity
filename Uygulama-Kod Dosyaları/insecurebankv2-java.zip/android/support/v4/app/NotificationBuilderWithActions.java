package android.support.v4.app;

import android.support.v4.app.NotificationCompatBase;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public interface NotificationBuilderWithActions {
    void addAction(NotificationCompatBase.Action action);
}
