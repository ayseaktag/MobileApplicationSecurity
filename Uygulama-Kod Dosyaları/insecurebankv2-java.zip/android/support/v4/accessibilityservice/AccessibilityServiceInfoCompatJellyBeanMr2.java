package android.support.v4.accessibilityservice;

import android.accessibilityservice.AccessibilityServiceInfo;
/* loaded from: classes.dex */
class AccessibilityServiceInfoCompatJellyBeanMr2 {
    AccessibilityServiceInfoCompatJellyBeanMr2() {
    }

    public static int getCapabilities(AccessibilityServiceInfo info) {
        return info.getCapabilities();
    }
}
