package android.support.v4.graphics;

import android.graphics.Bitmap;
/* loaded from: classes.dex */
class BitmapCompatKitKat {
    BitmapCompatKitKat() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static int getAllocationByteCount(Bitmap bitmap) {
        return bitmap.getAllocationByteCount();
    }
}
