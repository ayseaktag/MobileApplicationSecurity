package android.support.v7.recyclerview;
/* loaded from: classes.dex */
public final class R {

    /* loaded from: classes.dex */
    public static final class attr {
        public static final int layoutManager = 0x7f01005d;
        public static final int reverseLayout = 0x7f01005f;
        public static final int spanCount = 0x7f01005e;
        public static final int stackFromEnd = 0x7f010060;
    }

    /* loaded from: classes.dex */
    public static final class dimen {
        public static final int item_touch_helper_max_drag_scroll_per_frame = 0x7f080066;
    }

    /* loaded from: classes.dex */
    public static final class id {
        public static final int item_touch_helper_previous_elevation = 0x7f0c0005;
    }

    /* loaded from: classes.dex */
    public static final class styleable {
        public static final int[] RecyclerView = {16842948, jakhar.aseem.diva.R.attr.layoutManager, jakhar.aseem.diva.R.attr.spanCount, jakhar.aseem.diva.R.attr.reverseLayout, jakhar.aseem.diva.R.attr.stackFromEnd};
        public static final int RecyclerView_android_orientation = 0x00000000;
        public static final int RecyclerView_layoutManager = 0x00000001;
        public static final int RecyclerView_reverseLayout = 0x00000003;
        public static final int RecyclerView_spanCount = 0x00000002;
        public static final int RecyclerView_stackFromEnd = 0x00000004;
    }
}
