package android.support.v7.app;
@Deprecated
/* loaded from: classes.dex */
public class ActionBarActivity extends AppCompatActivity {
}
