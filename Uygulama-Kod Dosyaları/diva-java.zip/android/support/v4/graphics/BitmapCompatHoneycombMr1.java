package android.support.v4.graphics;

import android.graphics.Bitmap;
/* loaded from: classes.dex */
class BitmapCompatHoneycombMr1 {
    BitmapCompatHoneycombMr1() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static int getAllocationByteCount(Bitmap bitmap) {
        return bitmap.getByteCount();
    }
}
