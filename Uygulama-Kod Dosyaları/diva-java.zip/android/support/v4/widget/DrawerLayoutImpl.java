package android.support.v4.widget;
/* loaded from: classes.dex */
interface DrawerLayoutImpl {
    void setChildInsets(Object obj, boolean z);
}
