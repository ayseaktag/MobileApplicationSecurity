package android.support.v4.animation;
/* loaded from: classes.dex */
public interface AnimatorUpdateListenerCompat {
    void onAnimationUpdate(ValueAnimatorCompat valueAnimatorCompat);
}
