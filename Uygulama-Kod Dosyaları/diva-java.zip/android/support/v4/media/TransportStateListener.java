package android.support.v4.media;
/* loaded from: classes.dex */
public class TransportStateListener {
    public void onPlayingChanged(TransportController controller) {
    }

    public void onTransportControlsChanged(TransportController controller) {
    }
}
