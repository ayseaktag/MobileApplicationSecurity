package com.mwr.example.sieve;
/* loaded from: classes.dex */
public final class R {

    /* loaded from: classes.dex */
    public static final class attr {
    }

    /* loaded from: classes.dex */
    public static final class drawable {
        public static final int ic_launcher = 0x7f020000;
    }

    /* loaded from: classes.dex */
    public static final class id {
        public static final int addentry_button_cancel = 0x7f08000b;
        public static final int addentry_button_save = 0x7f08000a;
        public static final int addentry_edittext_email = 0x7f080004;
        public static final int addentry_edittext_password = 0x7f080007;
        public static final int addentry_edittext_passwordagain = 0x7f080006;
        public static final int addentry_edittext_service = 0x7f080001;
        public static final int addentry_edittext_username = 0x7f080002;
        public static final int addentry_textview_prompt = 0x7f08000c;
        public static final int button_add_cancel = 0x7f08000d;
        public static final int button_pin_submit = 0x7f08001a;
        public static final int edit_text_main_password = 0x7f080014;
        public static final int fileselect_list_path = 0x7f08000f;
        public static final int fileselect_textview_path = 0x7f08000e;
        public static final int format_pwlist_service = 0x7f080030;
        public static final int format_pwlist_username = 0x7f080031;
        public static final int login = 0x7f080012;
        public static final int mainlogin_button_login = 0x7f080010;
        public static final int mainlogin_edittext_entry = 0x7f080011;
        public static final int mainlogin_textview_prompt = 0x7f080013;
        public static final int menu_add = 0x7f080034;
        public static final int menu_add_delete = 0x7f080032;
        public static final int menu_settings = 0x7f080033;
        public static final int pinentry_edittext_pin = 0x7f080015;
        public static final int pinentry_edittext_pinagain = 0x7f080016;
        public static final int pinentry_edittext_pinold = 0x7f08001c;
        public static final int pinentry_textview_prompt = 0x7f08001b;
        public static final int pwlist_list_pwlist = 0x7f08001e;
        public static final int pwlist_textview_prompt = 0x7f08001f;
        public static final int settings_list = 0x7f080020;
        public static final int shortlogin_button_submit = 0x7f080028;
        public static final int shortlogin_edittext_entry = 0x7f080027;
        public static final int shortlogin_textview_prompt = 0x7f080029;
        public static final int textView1 = 0x7f080019;
        public static final int text_view_add_email = 0x7f080005;
        public static final int text_view_add_password = 0x7f080009;
        public static final int text_view_add_password_again = 0x7f080008;
        public static final int text_view_add_service = 0x7f080000;
        public static final int text_view_add_username = 0x7f080003;
        public static final int text_view_pin_password = 0x7f080017;
        public static final int text_view_pin_password_again = 0x7f080018;
        public static final int text_view_pin_password_old = 0x7f08001d;
        public static final int text_view_settings_delete = 0x7f080022;
        public static final int text_view_settings_net = 0x7f080024;
        public static final int text_view_settings_netrestore = 0x7f080026;
        public static final int text_view_settings_pinchange = 0x7f080021;
        public static final int text_view_settings_restore = 0x7f080025;
        public static final int text_view_settings_sd = 0x7f080023;
        public static final int text_view_welcome_password = 0x7f08002a;
        public static final int text_view_welcome_password_again = 0x7f08002c;
        public static final int welcome_button_submit = 0x7f08002f;
        public static final int welcome_edittext_password = 0x7f08002b;
        public static final int welcome_edittext_passwordagain = 0x7f08002d;
        public static final int welcome_textview_prompt = 0x7f08002e;
    }

    /* loaded from: classes.dex */
    public static final class layout {
        public static final int activity_add_entry = 0x7f030000;
        public static final int activity_file_select = 0x7f030001;
        public static final int activity_main_login = 0x7f030002;
        public static final int activity_pin = 0x7f030003;
        public static final int activity_pwlist = 0x7f030004;
        public static final int activity_settings = 0x7f030005;
        public static final int activity_short_login = 0x7f030006;
        public static final int activity_welcome = 0x7f030007;
        public static final int format_pwlist = 0x7f030008;
    }

    /* loaded from: classes.dex */
    public static final class menu {
        public static final int activity_add_entry_add = 0x7f070000;
        public static final int activity_add_entry_edit = 0x7f070001;
        public static final int activity_file_select = 0x7f070002;
        public static final int activity_main_login = 0x7f070003;
        public static final int activity_pin = 0x7f070004;
        public static final int activity_pwlist = 0x7f070005;
        public static final int activity_settings = 0x7f070006;
        public static final int activity_short_login = 0x7f070007;
        public static final int activity_welcome = 0x7f070008;
    }

    /* loaded from: classes.dex */
    public static final class string {
        public static final int action_sign_in_register = 0x7f05003a;
        public static final int action_sign_in_short = 0x7f05003b;
        public static final int addentry_confirm_delete = 0x7f050010;
        public static final int app_name = 0x7f050000;
        public static final int button_add_cancel = 0x7f05001f;
        public static final int button_add_save = 0x7f05001e;
        public static final int button_submit = 0x7f050020;
        public static final int error_field_required = 0x7f050041;
        public static final int error_incorrect_password = 0x7f050040;
        public static final int error_invalid_email = 0x7f05003e;
        public static final int error_invalid_password = 0x7f05003f;
        public static final int file_select_prompt = 0x7f050037;
        public static final int hello_world = 0x7f050001;
        public static final int login_progress_signing_in = 0x7f05003d;
        public static final int main_service_started = 0x7f050007;
        public static final int menu_add = 0x7f050003;
        public static final int menu_delete = 0x7f050004;
        public static final int menu_forgot_password = 0x7f05003c;
        public static final int menu_settings = 0x7f050002;
        public static final int pref_summary = 0x7f050006;
        public static final int pref_title = 0x7f050005;
        public static final int prompt_email = 0x7f050038;
        public static final int prompt_password = 0x7f050039;
        public static final int service_error_cantconnect = 0x7f050008;
        public static final int settings_confirm_backup = 0x7f050013;
        public static final int settings_confirm_delete = 0x7f050011;
        public static final int settings_confirm_netbackup = 0x7f050015;
        public static final int settings_confirm_netrestore = 0x7f050014;
        public static final int settings_confirm_restore = 0x7f050012;
        public static final int settings_error_cantchangepin = 0x7f050016;
        public static final int settings_error_cantread = 0x7f050018;
        public static final int settings_error_dbempty = 0x7f050017;
        public static final int text_view_add_email = 0x7f05001c;
        public static final int text_view_add_password = 0x7f05001b;
        public static final int text_view_add_password_again = 0x7f05001d;
        public static final int text_view_add_service = 0x7f050019;
        public static final int text_view_add_username = 0x7f05001a;
        public static final int text_view_entry_prompt = 0x7f050023;
        public static final int text_view_password = 0x7f050024;
        public static final int text_view_password_again = 0x7f050025;
        public static final int text_view_password_dontmatch = 0x7f050030;
        public static final int text_view_password_notstandard = 0x7f05002d;
        public static final int text_view_password_standard = 0x7f05002e;
        public static final int text_view_password_tooshort = 0x7f05002f;
        public static final int text_view_pin_dontmatch = 0x7f05002b;
        public static final int text_view_pin_message = 0x7f050027;
        public static final int text_view_pin_notold = 0x7f05002c;
        public static final int text_view_pin_notstandard = 0x7f050029;
        public static final int text_view_pin_standard = 0x7f050028;
        public static final int text_view_pin_tooshort = 0x7f05002a;
        public static final int text_view_pwlist_prompt = 0x7f050021;
        public static final int text_view_settings_delete = 0x7f050035;
        public static final int text_view_settings_net = 0x7f050032;
        public static final int text_view_settings_netrestore = 0x7f050033;
        public static final int text_view_settings_pinchange = 0x7f050036;
        public static final int text_view_settings_restore = 0x7f050034;
        public static final int text_view_settings_sd = 0x7f050031;
        public static final int text_view_short_prompt = 0x7f050022;
        public static final int text_view_welcome_message = 0x7f050026;
        public static final int title_activity_add_entry = 0x7f05000b;
        public static final int title_activity_file_select = 0x7f05000f;
        public static final int title_activity_pin = 0x7f05000e;
        public static final int title_activity_pwlist = 0x7f050009;
        public static final int title_activity_settings = 0x7f05000a;
        public static final int title_activity_short_login = 0x7f05000c;
        public static final int title_activity_welcome = 0x7f05000d;
    }

    /* loaded from: classes.dex */
    public static final class style {
        public static final int AppBaseTheme = 0x7f060000;
        public static final int AppTheme = 0x7f060001;
        public static final int LoginFormContainer = 0x7f060002;
    }

    /* loaded from: classes.dex */
    public static final class xml {
        public static final int prefrences = 0x7f040000;
    }
}
