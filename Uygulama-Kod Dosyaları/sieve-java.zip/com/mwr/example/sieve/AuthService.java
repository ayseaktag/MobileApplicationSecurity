package com.mwr.example.sieve;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.CursorLoader;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.support.v4.app.NotificationCompat;
import android.support.v4.view.accessibility.AccessibilityEventCompat;
import android.util.Log;
/* loaded from: classes.dex */
public class AuthService extends Service {
    static final int MSG_CHECK = 2354;
    static final int MSG_CHECK_IF_INITALISED = 2;
    static final int MSG_FIRST_LAUNCH = 4;
    static final int MSG_SAY_HELLO = 1;
    static final int MSG_SET = 6345;
    static final int MSG_UNREGISTER = -1;
    public static final String PASSWORD = "com.mwr.example.sieve.PASSWORD";
    public static final String PIN = "com.mwr.example.sieve.PIN";
    private static final String TAG = "m_AuthService";
    static final int TYPE_KEY = 7452;
    static final int TYPE_PIN = 9234;
    private int NOTIFICATION = R.string.app_name;
    private NotificationManager nManager;
    private Messenger responseHandler;
    private Messenger serviceHandler;
    private Looper serviceLooper;

    @Override // android.app.Service
    public void onCreate() {
        this.nManager = (NotificationManager) getSystemService("notification");
        HandlerThread thread = new HandlerThread(TAG, 10);
        thread.start();
        this.serviceLooper = thread.getLooper();
        this.serviceHandler = new Messenger(new MessageHandler(this.serviceLooper));
    }

    @Override // android.app.Service
    public IBinder onBind(Intent arg0) {
        return this.serviceHandler.getBinder();
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int flags, int startId) {
        return 1;
    }

    @Override // android.app.Service
    public void onDestroy() {
        this.nManager.cancelAll();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void showNotification() {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this).setSmallIcon(R.drawable.ic_launcher).setContentTitle(getText(R.string.app_name)).setOngoing(true).setContentText("Click to access your passwords");
        Intent resultIntent = new Intent(this, MainLoginActivity.class);
        resultIntent.addFlags(AccessibilityEventCompat.TYPE_TOUCH_INTERACTION_START);
        PendingIntent resultPendingIntent = PendingIntent.getActivity(getApplicationContext(), 0, resultIntent, 268435456);
        builder.setContentIntent(resultPendingIntent);
        this.nManager.notify(this.NOTIFICATION, builder.build());
    }

    /* loaded from: classes.dex */
    private final class MessageHandler extends Handler {
        public MessageHandler(Looper looper) {
            super(looper);
        }

        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            int responseCode;
            int returnVal;
            int responseCode2;
            int responseCode3;
            int returnVal2;
            AuthService.this.responseHandler = msg.replyTo;
            Bundle returnBundle = (Bundle) msg.obj;
            switch (msg.what) {
                case 4:
                    if (!AuthService.this.checkKeyExists()) {
                        responseCode2 = 33;
                    } else if (AuthService.this.checkPinExists()) {
                        responseCode2 = 31;
                    } else {
                        responseCode2 = 32;
                    }
                    sendResponseMessage(3, responseCode2, 1, null);
                    return;
                case AuthService.MSG_CHECK /* 2354 */:
                    if (msg.arg1 == AuthService.TYPE_KEY) {
                        responseCode3 = 42;
                        String recievedString = returnBundle.getString("com.mwr.example.sieve.PASSWORD");
                        if (AuthService.this.verifyKey(recievedString)) {
                            AuthService.this.showNotification();
                            returnVal2 = 0;
                        } else {
                            returnVal2 = 1;
                        }
                    } else if (msg.arg1 == AuthService.TYPE_PIN) {
                        responseCode3 = 41;
                        String recievedString2 = returnBundle.getString("com.mwr.example.sieve.PIN");
                        if (AuthService.this.verifyPin(recievedString2)) {
                            returnBundle = new Bundle();
                            returnBundle.putString("com.mwr.example.sieve.PASSWORD", AuthService.this.getKey());
                            returnVal2 = 0;
                        } else {
                            returnVal2 = 1;
                        }
                    } else {
                        sendUnrecognisedMessage();
                        return;
                    }
                    sendResponseMessage(5, responseCode3, returnVal2, returnBundle);
                    return;
                case AuthService.MSG_SET /* 6345 */:
                    if (msg.arg1 == AuthService.TYPE_KEY) {
                        responseCode = 42;
                        String recievedString3 = returnBundle.getString("com.mwr.example.sieve.PASSWORD");
                        if (AuthService.this.setKey(recievedString3)) {
                            returnVal = 0;
                        } else {
                            returnVal = 1;
                        }
                    } else if (msg.arg1 == AuthService.TYPE_PIN) {
                        responseCode = 41;
                        String recievedString4 = returnBundle.getString("com.mwr.example.sieve.PIN");
                        if (AuthService.this.setPin(recievedString4)) {
                            returnVal = 0;
                        } else {
                            returnVal = 1;
                        }
                    } else {
                        sendUnrecognisedMessage();
                        return;
                    }
                    sendResponseMessage(4, responseCode, returnVal, null);
                    return;
                default:
                    Log.e(AuthService.TAG, "Error: unrecognized command: " + msg.what);
                    sendUnrecognisedMessage();
                    super.handleMessage(msg);
                    return;
            }
        }

        private void sendResponseMessage(int command, int arg1, int arg2, Bundle bundle) {
            try {
                Message msg = Message.obtain(null, command, arg1, arg2);
                if (bundle != null) {
                    msg.setData(bundle);
                }
                AuthService.this.responseHandler.send(msg);
            } catch (RemoteException e) {
                Log.e(AuthService.TAG, "Unable to send message: " + command);
            }
        }

        private void sendUnrecognisedMessage() {
            try {
                Message msg = Message.obtain(null, 111111, 122222, 1, null);
                AuthService.this.responseHandler.send(msg);
            } catch (RemoteException e) {
                Log.e(AuthService.TAG, "Unable to send message");
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean verifyKey(String key) {
        String[] projection = {PWTable.KEY_COLUMN_NAME_MAIN};
        String[] selectionArgs = {key};
        Cursor c = new CursorLoader(this, DBContentProvider.KEYS_URI, projection, "Password = ?", selectionArgs, null).loadInBackground();
        return c.getCount() == 1;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean verifyPin(String PIN2) {
        String[] projection = {PWTable.KEY_COLUMN_NAME_SHORT};
        String[] selectionArgs = {PIN2};
        Cursor c = new CursorLoader(this, DBContentProvider.KEYS_URI, projection, "pin = ?", selectionArgs, null).loadInBackground();
        return c.getCount() == 1;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean setKey(String key) {
        ContentValues out = new ContentValues();
        out.put(PWTable.KEY_COLUMN_NAME_MAIN, key);
        Uri result = getContentResolver().insert(DBContentProvider.KEYS_URI, out);
        return result != null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean setPin(String key) {
        ContentValues out = new ContentValues();
        out.put(PWTable.KEY_COLUMN_NAME_SHORT, key);
        int r = getContentResolver().update(DBContentProvider.KEYS_URI, out, "pin IS NULL", null);
        return r > 0;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public String getKey() {
        String[] projection = {PWTable.KEY_COLUMN_NAME_MAIN};
        Cursor c = new CursorLoader(this, DBContentProvider.KEYS_URI, projection, null, null, null).loadInBackground();
        c.moveToFirst();
        return c.getString(c.getColumnIndex(PWTable.KEY_COLUMN_NAME_MAIN));
    }

    public boolean checkKeyExists() {
        String[] projection = {PWTable.KEY_COLUMN_NAME_MAIN};
        Cursor c = new CursorLoader(this, DBContentProvider.KEYS_URI, projection, null, null, null).loadInBackground();
        return c.getCount() > 0;
    }

    public boolean checkPinExists() {
        String[] projection = {PWTable.KEY_COLUMN_NAME_SHORT};
        Cursor c = new CursorLoader(this, DBContentProvider.KEYS_URI, projection, null, null, null).loadInBackground();
        boolean exists = false;
        c.moveToFirst();
        for (int i = 0; i < c.getCount(); i++) {
            exists = c.getString(c.getColumnIndex(PWTable.KEY_COLUMN_NAME_SHORT)) != null;
        }
        return exists;
    }
}
