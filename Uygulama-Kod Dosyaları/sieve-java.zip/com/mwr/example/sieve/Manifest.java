package com.mwr.example.sieve;
/* loaded from: classes.dex */
public final class Manifest {

    /* loaded from: classes.dex */
    public static final class permission {
        public static final String READ_KEYS = "com.mwr.example.sieve.READ_KEYS";
        public static final String WRITE_KEYS = "com.mwr.example.sieve.WRITE_KEYS";
    }
}
