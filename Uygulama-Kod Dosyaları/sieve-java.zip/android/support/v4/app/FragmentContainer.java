package android.support.v4.app;

import android.view.View;
/* compiled from: FragmentManager.java */
/* loaded from: classes.dex */
interface FragmentContainer {
    View findViewById(int i);
}
