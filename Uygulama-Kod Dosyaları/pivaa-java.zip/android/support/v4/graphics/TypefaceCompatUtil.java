package android.support.v4.graphics;

import android.content.Context;
import android.content.res.Resources;
import android.os.Process;
import android.support.annotation.RequiresApi;
import android.support.annotation.RestrictTo;
import android.util.Log;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
/* loaded from: classes.dex */
public class TypefaceCompatUtil {
    private static final String CACHE_FILE_PREFIX = ".font";
    private static final String TAG = "TypefaceCompatUtil";

    private TypefaceCompatUtil() {
    }

    public static File getTempFile(Context context) {
        String prefix = CACHE_FILE_PREFIX + Process.myPid() + "-" + Process.myTid() + "-";
        for (int i = 0; i < 100; i++) {
            File file = new File(context.getCacheDir(), prefix + i);
            if (file.createNewFile()) {
                return file;
            }
        }
        return null;
    }

    @RequiresApi(19)
    private static ByteBuffer mmap(File file) {
        try {
            FileInputStream fis = new FileInputStream(file);
            FileChannel channel = fis.getChannel();
            long size = channel.size();
            MappedByteBuffer map = channel.map(FileChannel.MapMode.READ_ONLY, 0L, size);
            if (fis != null) {
                if (0 != 0) {
                    fis.close();
                } else {
                    fis.close();
                }
            }
            return map;
        } catch (IOException e) {
            return null;
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:28:0x004f
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:92)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:52)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:44)
        */
    @android.support.annotation.RequiresApi(19)
    public static java.nio.ByteBuffer mmap(android.content.Context r13, android.os.CancellationSignal r14, android.net.Uri r15) {
        /*
            android.content.ContentResolver r9 = r13.getContentResolver()
            java.lang.String r1 = "r"
            android.os.ParcelFileDescriptor r8 = r9.openFileDescriptor(r15, r1, r14)     // Catch: java.io.IOException -> L48
            r11 = 0
            java.io.FileInputStream r7 = new java.io.FileInputStream     // Catch: java.lang.Throwable -> L3a
            java.io.FileDescriptor r1 = r8.getFileDescriptor()     // Catch: java.lang.Throwable -> L3a
            r7.<init>(r1)     // Catch: java.lang.Throwable -> L3a
            r10 = 0
            java.nio.channels.FileChannel r0 = r7.getChannel()     // Catch: java.lang.Throwable -> L5b
            long r4 = r0.size()     // Catch: java.lang.Throwable -> L5b
            java.nio.channels.FileChannel$MapMode r1 = java.nio.channels.FileChannel.MapMode.READ_ONLY     // Catch: java.lang.Throwable -> L5b
            r2 = 0
            java.nio.MappedByteBuffer r1 = r0.map(r1, r2, r4)     // Catch: java.lang.Throwable -> L5b
            if (r7 == 0) goto L2d
            if (r10 == 0) goto L4b
            r7.close()     // Catch: java.lang.Throwable -> L35
        L2d:
            if (r8 == 0) goto L34
            if (r11 == 0) goto L57
            r8.close()     // Catch: java.lang.Throwable -> L52
        L34:
            return r1
        L35:
            r2 = move-exception
            r10.addSuppressed(r2)     // Catch: java.lang.Throwable -> L3a
            goto L2d
        L3a:
            r1 = move-exception
            throw r1     // Catch: java.lang.Throwable -> L3c
        L3c:
            r2 = move-exception
            r12 = r2
            r2 = r1
            r1 = r12
        L40:
            if (r8 == 0) goto L47
            if (r2 == 0) goto L77
            r8.close()     // Catch: java.lang.Throwable -> L72
        L47:
            throw r1     // Catch: java.io.IOException -> L48
        L48:
            r6 = move-exception
            r1 = 0
            goto L34
        L4b:
            r7.close()     // Catch: java.lang.Throwable -> L3a
            goto L2d
        L4f:
            r1 = move-exception
            r2 = r11
            goto L40
        L52:
            r2 = move-exception
            r11.addSuppressed(r2)     // Catch: java.io.IOException -> L48
            goto L34
        L57:
            r8.close()     // Catch: java.io.IOException -> L48
            goto L34
        L5b:
            r1 = move-exception
            throw r1     // Catch: java.lang.Throwable -> L5d
        L5d:
            r2 = move-exception
            r12 = r2
            r2 = r1
            r1 = r12
        L61:
            if (r7 == 0) goto L68
            if (r2 == 0) goto L6e
            r7.close()     // Catch: java.lang.Throwable -> L69
        L68:
            throw r1     // Catch: java.lang.Throwable -> L3a
        L69:
            r3 = move-exception
            r2.addSuppressed(r3)     // Catch: java.lang.Throwable -> L3a
            goto L68
        L6e:
            r7.close()     // Catch: java.lang.Throwable -> L3a
            goto L68
        L72:
            r3 = move-exception
            r2.addSuppressed(r3)     // Catch: java.io.IOException -> L48
            goto L47
        L77:
            r8.close()     // Catch: java.io.IOException -> L48
            goto L47
        L7b:
            r1 = move-exception
            r2 = r10
            goto L61
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.graphics.TypefaceCompatUtil.mmap(android.content.Context, android.os.CancellationSignal, android.net.Uri):java.nio.ByteBuffer");
    }

    @RequiresApi(19)
    public static ByteBuffer copyToDirectBuffer(Context context, Resources res, int id) {
        ByteBuffer byteBuffer = null;
        File tmpFile = getTempFile(context);
        if (tmpFile != null) {
            try {
                if (copyToFile(tmpFile, res, id)) {
                    byteBuffer = mmap(tmpFile);
                }
            } finally {
                tmpFile.delete();
            }
        }
        return byteBuffer;
    }

    public static boolean copyToFile(File file, InputStream is) {
        Throwable th;
        FileOutputStream os;
        FileOutputStream os2 = null;
        try {
            try {
                os = new FileOutputStream(file, false);
            } catch (IOException e) {
                e = e;
            }
        } catch (Throwable th2) {
            th = th2;
        }
        try {
            byte[] buffer = new byte[1024];
            while (true) {
                int readLen = is.read(buffer);
                if (readLen != -1) {
                    os.write(buffer, 0, readLen);
                } else {
                    closeQuietly(os);
                    return true;
                }
            }
        } catch (IOException e2) {
            e = e2;
            os2 = os;
            Log.e(TAG, "Error copying resource contents to temp file: " + e.getMessage());
            closeQuietly(os2);
            return false;
        } catch (Throwable th3) {
            th = th3;
            os2 = os;
            closeQuietly(os2);
            throw th;
        }
    }

    public static boolean copyToFile(File file, Resources res, int id) {
        InputStream is = null;
        try {
            is = res.openRawResource(id);
            return copyToFile(file, is);
        } finally {
            closeQuietly(is);
        }
    }

    public static void closeQuietly(Closeable c) {
        if (c != null) {
            try {
                c.close();
            } catch (IOException e) {
            }
        }
    }
}
