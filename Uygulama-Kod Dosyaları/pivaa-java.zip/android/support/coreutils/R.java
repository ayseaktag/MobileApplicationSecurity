package android.support.coreutils;
/* loaded from: classes.dex */
public final class R {

    /* loaded from: classes.dex */
    public static final class attr {
        public static final int font = 0x7f03008f;
        public static final int fontProviderAuthority = 0x7f030091;
        public static final int fontProviderCerts = 0x7f030092;
        public static final int fontProviderFetchStrategy = 0x7f030093;
        public static final int fontProviderFetchTimeout = 0x7f030094;
        public static final int fontProviderPackage = 0x7f030095;
        public static final int fontProviderQuery = 0x7f030096;
        public static final int fontStyle = 0x7f030097;
        public static final int fontWeight = 0x7f030098;
    }

    /* loaded from: classes.dex */
    public static final class bool {
        public static final int abc_action_bar_embed_tabs = 0x7f040000;
    }

    /* loaded from: classes.dex */
    public static final class color {
        public static final int notification_action_color_filter = 0x7f050049;
        public static final int notification_icon_bg_color = 0x7f05004a;
        public static final int ripple_material_light = 0x7f050055;
        public static final int secondary_text_default_material_light = 0x7f050057;
    }

    /* loaded from: classes.dex */
    public static final class dimen {
        public static final int compat_button_inset_horizontal_material = 0x7f06004c;
        public static final int compat_button_inset_vertical_material = 0x7f06004d;
        public static final int compat_button_padding_horizontal_material = 0x7f06004e;
        public static final int compat_button_padding_vertical_material = 0x7f06004f;
        public static final int compat_control_corner_material = 0x7f060050;
        public static final int notification_action_icon_size = 0x7f060087;
        public static final int notification_action_text_size = 0x7f060088;
        public static final int notification_big_circle_margin = 0x7f060089;
        public static final int notification_content_margin_start = 0x7f06008a;
        public static final int notification_large_icon_height = 0x7f06008b;
        public static final int notification_large_icon_width = 0x7f06008c;
        public static final int notification_main_column_padding_top = 0x7f06008d;
        public static final int notification_media_narrow_margin = 0x7f06008e;
        public static final int notification_right_icon_size = 0x7f06008f;
        public static final int notification_right_side_padding_top = 0x7f060090;
        public static final int notification_small_icon_background_padding = 0x7f060091;
        public static final int notification_small_icon_size_as_large = 0x7f060092;
        public static final int notification_subtext_size = 0x7f060093;
        public static final int notification_top_pad = 0x7f060094;
        public static final int notification_top_pad_large_text = 0x7f060095;
    }

    /* loaded from: classes.dex */
    public static final class drawable {
        public static final int notification_action_background = 0x7f070065;
        public static final int notification_bg = 0x7f070066;
        public static final int notification_bg_low = 0x7f070067;
        public static final int notification_bg_low_normal = 0x7f070068;
        public static final int notification_bg_low_pressed = 0x7f070069;
        public static final int notification_bg_normal = 0x7f07006a;
        public static final int notification_bg_normal_pressed = 0x7f07006b;
        public static final int notification_icon_background = 0x7f07006c;
        public static final int notification_template_icon_bg = 0x7f07006d;
        public static final int notification_template_icon_low_bg = 0x7f07006e;
        public static final int notification_tile_bg = 0x7f07006f;
        public static final int notify_panel_notification_icon_bg = 0x7f070070;
    }

    /* loaded from: classes.dex */
    public static final class id {
        public static final int action_container = 0x7f080010;
        public static final int action_divider = 0x7f080014;
        public static final int action_image = 0x7f080016;
        public static final int action_text = 0x7f080021;
        public static final int actions = 0x7f080023;
        public static final int async = 0x7f080029;
        public static final int blocking = 0x7f08002f;
        public static final int chronometer = 0x7f08004b;
        public static final int forever = 0x7f08006d;
        public static final int icon = 0x7f08007a;
        public static final int icon_group = 0x7f08007b;
        public static final int info = 0x7f08007e;
        public static final int italic = 0x7f080082;
        public static final int line1 = 0x7f080086;
        public static final int line3 = 0x7f080087;
        public static final int normal = 0x7f080098;
        public static final int notification_background = 0x7f080099;
        public static final int notification_main_column = 0x7f08009a;
        public static final int notification_main_column_container = 0x7f08009b;
        public static final int right_icon = 0x7f0800ae;
        public static final int right_side = 0x7f0800af;
        public static final int text = 0x7f0800da;
        public static final int text2 = 0x7f0800db;
        public static final int time = 0x7f0800e2;
        public static final int title = 0x7f0800e3;
    }

    /* loaded from: classes.dex */
    public static final class integer {
        public static final int status_bar_notification_info_maxnum = 0x7f090009;
    }

    /* loaded from: classes.dex */
    public static final class layout {
        public static final int notification_action = 0x7f0a003e;
        public static final int notification_action_tombstone = 0x7f0a003f;
        public static final int notification_template_custom_big = 0x7f0a0046;
        public static final int notification_template_icon_group = 0x7f0a0047;
        public static final int notification_template_part_chronometer = 0x7f0a004b;
        public static final int notification_template_part_time = 0x7f0a004c;
    }

    /* loaded from: classes.dex */
    public static final class string {
        public static final int status_bar_notification_info_overflow = 0x7f0d0034;
    }

    /* loaded from: classes.dex */
    public static final class style {
        public static final int TextAppearance_Compat_Notification = 0x7f0e0103;
        public static final int TextAppearance_Compat_Notification_Info = 0x7f0e0104;
        public static final int TextAppearance_Compat_Notification_Line2 = 0x7f0e0106;
        public static final int TextAppearance_Compat_Notification_Time = 0x7f0e0109;
        public static final int TextAppearance_Compat_Notification_Title = 0x7f0e010b;
        public static final int Widget_Compat_NotificationActionContainer = 0x7f0e0181;
        public static final int Widget_Compat_NotificationActionText = 0x7f0e0182;
    }

    /* loaded from: classes.dex */
    public static final class styleable {
        public static final int[] FontFamily = {com.htbridge.pivaa.R.attr.fontProviderAuthority, com.htbridge.pivaa.R.attr.fontProviderCerts, com.htbridge.pivaa.R.attr.fontProviderFetchStrategy, com.htbridge.pivaa.R.attr.fontProviderFetchTimeout, com.htbridge.pivaa.R.attr.fontProviderPackage, com.htbridge.pivaa.R.attr.fontProviderQuery};
        public static final int[] FontFamilyFont = {com.htbridge.pivaa.R.attr.font, com.htbridge.pivaa.R.attr.fontStyle, com.htbridge.pivaa.R.attr.fontWeight};
        public static final int FontFamilyFont_font = 0x00000000;
        public static final int FontFamilyFont_fontStyle = 0x00000001;
        public static final int FontFamilyFont_fontWeight = 0x00000002;
        public static final int FontFamily_fontProviderAuthority = 0x00000000;
        public static final int FontFamily_fontProviderCerts = 0x00000001;
        public static final int FontFamily_fontProviderFetchStrategy = 0x00000002;
        public static final int FontFamily_fontProviderFetchTimeout = 0x00000003;
        public static final int FontFamily_fontProviderPackage = 0x00000004;
        public static final int FontFamily_fontProviderQuery = 0x00000005;
    }
}
