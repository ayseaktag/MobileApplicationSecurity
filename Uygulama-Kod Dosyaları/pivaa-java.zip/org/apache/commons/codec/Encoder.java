package org.apache.commons.codec;
/* loaded from: classes.dex */
public interface Encoder {
    Object encode(Object obj) throws EncoderException;
}
