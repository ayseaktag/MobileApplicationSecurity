package org.apache.commons.codec;
/* loaded from: classes.dex */
public interface Decoder {
    Object decode(Object obj) throws DecoderException;
}
