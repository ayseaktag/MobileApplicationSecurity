package org.apache.commons.codec;
/* loaded from: classes.dex */
public interface StringDecoder extends Decoder {
    String decode(String str) throws DecoderException;
}
