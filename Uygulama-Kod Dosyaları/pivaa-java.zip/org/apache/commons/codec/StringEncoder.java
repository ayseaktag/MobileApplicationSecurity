package org.apache.commons.codec;
/* loaded from: classes.dex */
public interface StringEncoder extends Encoder {
    String encode(String str) throws EncoderException;
}
