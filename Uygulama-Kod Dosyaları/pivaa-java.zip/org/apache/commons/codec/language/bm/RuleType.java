package org.apache.commons.codec.language.bm;
/* loaded from: classes.dex */
public enum RuleType {
    APPROX("approx"),
    EXACT("exact"),
    RULES("rules");
    
    private final String name;

    RuleType(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }
}
