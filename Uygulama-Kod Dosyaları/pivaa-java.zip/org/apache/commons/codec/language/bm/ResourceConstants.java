package org.apache.commons.codec.language.bm;
/* loaded from: classes.dex */
class ResourceConstants {
    static final String CMT = "//";
    static final String ENCODING = "UTF-8";
    static final String EXT_CMT_END = "*/";
    static final String EXT_CMT_START = "/*";

    ResourceConstants() {
    }
}
