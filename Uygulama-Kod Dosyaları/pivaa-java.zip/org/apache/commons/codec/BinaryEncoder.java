package org.apache.commons.codec;
/* loaded from: classes.dex */
public interface BinaryEncoder extends Encoder {
    byte[] encode(byte[] bArr) throws EncoderException;
}
