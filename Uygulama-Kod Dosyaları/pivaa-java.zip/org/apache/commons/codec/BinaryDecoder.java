package org.apache.commons.codec;
/* loaded from: classes.dex */
public interface BinaryDecoder extends Decoder {
    byte[] decode(byte[] bArr) throws DecoderException;
}
