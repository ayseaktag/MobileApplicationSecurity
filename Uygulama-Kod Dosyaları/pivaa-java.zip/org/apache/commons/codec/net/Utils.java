package org.apache.commons.codec.net;

import org.apache.commons.codec.DecoderException;
/* loaded from: classes.dex */
class Utils {
    private static final int RADIX = 16;

    Utils() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static int digit16(byte b) throws DecoderException {
        int i = Character.digit((char) b, 16);
        if (i != -1) {
            return i;
        }
        throw new DecoderException("Invalid URL encoding: not a valid digit (radix 16): " + ((int) b));
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static char hexDigit(int b) {
        return Character.toUpperCase(Character.forDigit(b & 15, 16));
    }
}
